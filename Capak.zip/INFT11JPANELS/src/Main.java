import sk.uniza.fri.VtipneOkno;

/**
 * Created by IntelliJ IDEA.
 * User: timka
 * Date: 5. 5. 2021
 * Time: 12:08
 */
public class Main {

    public static void main(String[] args) {
        //JOptionPane.showConfirmDialog(null, "Chceš cookie?");
        //JOptionPane.showConfirmDialog(null, "heh.");

        VtipneOkno okno = new VtipneOkno();
        okno.zobraz();
    }
}
