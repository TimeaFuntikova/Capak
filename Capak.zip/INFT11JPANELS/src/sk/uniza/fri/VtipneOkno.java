package sk.uniza.fri;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

/**
 * 5. 5. 2021 - 12:08
 *
 * @author timea
 */
public class VtipneOkno {

    private JFrame okno;
    private JButton button1;
    private JButton button2;

    public VtipneOkno() {

        //TODO: 1. Vytvorenie panela a pridanie tlačidiel do panela:
        this.okno = new JFrame("Vtipná appka, heh.");
        this.okno.setSize(450, 150);
        this.okno.setDefaultCloseOperation(3); //magic numbers v Jave sú na veľa miestach, definované ako konštanty v nejakej triede
        this.okno.setLocationRelativeTo(null);
        this.okno.setLayout(new BorderLayout());
        this.okno.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                //tu sa dá vyhodiť metóda že či je všetko uložené
                JOptionPane.showMessageDialog(null, "Niečo musíš zvoliť.");
            }
        });



        JPanel buttons = new JPanel(); //buttons.setLayout(new FlowLayout()); // netreba, lebo panel má flowYlayout
        this.button1 = this.vytvorButton("ano");
        buttons.add(this.button1);
        this.button2 = this.vytvorButton("nie");
        buttons.add(this.button2);

        JLabel label = new JLabel("Chceš čapák?");
        label.setBorder(new EmptyBorder(10, 10, 10, 10));
        this.okno.add(label, BorderLayout.NORTH);
        this.okno.add(buttons, BorderLayout.CENTER);

        // button1.addMouseListener(new Vymienac());
        //button2.addMouseListener(new Vymienac());
    }


    //TODO: 2. Chceme, aby po kliknutí sa dalo neičo vypísať
    /** Nápad cez listener.
     * Poslucháč : manažér imputu.
     */
    private JButton vytvorButton(String text) {
        JButton button = new JButton(text);
        button.addActionListener(e -> {
            JOptionPane.showMessageDialog(null, "Hehe, čapák letíííí.");
            System.exit(0);
        });
        button.setFocusable(false);
        button.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) { //dostanem komponent tlačidla, na ktoré som klikol.
                //má návratovú hodnotu komponent... ak mu príde niečo ine, tak programátor urobil niečo zlé, nie používateľ

                if (((JButton)e.getComponent()).getText().equals("nie")) {

                    String text1 = VtipneOkno.this.button1.getText();
                    VtipneOkno.this.button1.setText(VtipneOkno.this.button2.getText());
                    VtipneOkno.this.button2.setText(text1);
                }
            }
        });

        return button;
    }

    public void zobraz() {
        this.okno.setVisible(true);

    }
}
